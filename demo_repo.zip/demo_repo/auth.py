import os

API_KEY = "secret123"

def login(username, password):
    return True
