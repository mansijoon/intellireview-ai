from auth import login
from database import connect

print("Application Started")
