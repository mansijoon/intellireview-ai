import sqlite3
import os

def connect():
    return sqlite3.connect("app.db")
